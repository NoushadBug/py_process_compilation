public class Client {
    private String name;
    private String surname;
    private Account savingAccount;
    private double grossSalary;
    private double netSalary;
    private double netSalaryPerWeek;
    private boolean isResident;
    private double tax;
    private double medicare;
    private double weeklyExpenses;

    public double getNetSalaryPerWeek() {
        return netSalaryPerWeek;
    }

    public void setNetSalaryPerWeek(double netSalaryPerWeek) {
        this.netSalaryPerWeek = netSalaryPerWeek;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public Account getSavingAccount() {
        return savingAccount;
    }

    public double getGrossSalary() {
        return grossSalary;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public boolean isResident() {
        return isResident;
    }

    public double getTax() {
        return tax;
    }

    public double getMedicare() {
        return medicare;
    }

    public double getWeeklyExpenses() {
        return weeklyExpenses;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setSavingAccount(Account savingAccount) {
        this.savingAccount = savingAccount;
    }

    public void setGrossSalary(double grossSalary) {
        this.grossSalary = grossSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }

    public void setResident(boolean isResident) {
        this.isResident = isResident;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public void setMedicare(double medicare) {
        this.medicare = medicare;
    }

    public void setWeeklyExpenses(double weeklyExpenses) {
        this.weeklyExpenses = weeklyExpenses;
    }

    public void CalcTax() {
        double income = grossSalary;
        if (isResident) {
            if (income <= 18200) {
                tax = 0;
            } else if (income <= 45000) {
                tax = (income - 18200) * 0.19;
            } else if (income <= 120000) {
                tax = (income - 45000) * 0.325 + 5092;
            } else if (income <= 180000) {
                tax = (income - 120000) * 0.37 + 29467;
            } else {
                tax = (income - 180000) * 0.45 + 51667;
            }
        } else {
            if (income <= 45000) {
                tax = income * 0.325;
            } else if (income <= 120000) {
                tax = (income - 45000) * 0.37 + 14625;
            } else {
                tax = (income - 120000) * 0.45 + 51625;
            }
        }

        netSalary -= tax;
    }

    public void CalcMedicare() {
        if (isResident && grossSalary > 29.032) {
            medicare = grossSalary * 0.02;
        } else {

            medicare = 0;
        }

        netSalary = grossSalary - medicare;
    }
}
