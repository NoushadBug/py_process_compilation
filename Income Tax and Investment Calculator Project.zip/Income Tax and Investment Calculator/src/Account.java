public class Account
{
    private double rate;
    private double amount;
    private  int numberOfWeeks;

    public double getRate()
    {
        return rate;
    }

    public double getAmount()
    {
        return amount;
    }

    public int getNumberOfWeeks()
    {
        return numberOfWeeks;
    }

    public void setRate(double rate)
    {
        this.rate = rate;
    }

    public void setAmount(double amount)
    {
        this.amount = amount;
    }

    public void setNumberOfWeeks(int numberOfWeeks)
    {
        this.numberOfWeeks = numberOfWeeks;
    }

    public String calcInvestment() {
        double investmentAmount = 0.0;
        String output = "Weeks\tMoney\n";

        // Calculate investment account output
        for (int i = 1; i <= numberOfWeeks; i++) {

            if(i%4==0)
            {
                investmentAmount += amount * i;
                investmentAmount = investmentAmount * rate;
                output += i + "\t$" + String.format("%.2f", investmentAmount) + "\n";
            }else if (i==18){
                investmentAmount += amount * 2;
                output += i + "\t$" + String.format("%.2f", investmentAmount) + "\n";
            }

        }

        return output;
    }
}
