import java.util.Scanner;

public class CalculatorInterface {
    private static final int WEEKS_IN_YEAR = 52;
    private final Scanner scanner;
    private final Client client;

    public CalculatorInterface() {
        scanner = new Scanner(System.in);
        client = new Client();
    }

    public static void main(String[] args) {
        CalculatorInterface c = new CalculatorInterface();
        c.Run();
    }

    private void Run() {
        String userName;
        String userSurname;
        String response;
        double salary;
        boolean resident;
        boolean invest;

        //------------ Task 1 ------------
        // Enter name and surname
        do {
            System.out.println("Enter user name: ");
            userName = scanner.nextLine();

            System.out.println("Enter user surname: ");
            userSurname = scanner.nextLine();

            if (userName.trim().isEmpty() || userSurname.trim().isEmpty()) {
                System.out.println("Error: First name or last name cannot be empty.");
            }
        } while (userName.trim().isEmpty() || userSurname.trim().isEmpty());

        //Checking user is resident?
        do {
            System.out.print("Is the client a resident (Y/N)? ");
            response = scanner.nextLine().trim().toLowerCase();


            if (response.equals("y") || response.equals("yes")) {
                resident = true;
            } else if (response.equals("n") || response.equals("no")) {
                resident = false;
            } else {
                System.out.println("Error: Invalid input. Please enter Yes/No or Y/N.");
                resident = false; // reset resident too false to repeat loop
            }

        } while (!response.equals("y") && !response.equals("yes") && !response.equals("n") && !response.equals("no"));

        //Entering annual salary
        do {
            System.out.println("Enter your annual salary: ");
            salary = scanner.nextDouble();

            if (salary <= 0) {
                System.out.println("Salary must be a positive number and different from zero.");
            }
        } while (salary <= 0);

        // Set all info to client object
        client.setName(userName);
        client.setSurname(userSurname);
        client.setGrossSalary(salary);
        client.setResident(resident);
        client.setSavingAccount(new Account());

        //calculate Medicare and Tax
        client.CalcMedicare();
        client.CalcTax();
        client.setNetSalaryPerWeek(client.getNetSalary() / WEEKS_IN_YEAR);

        //Displaying data on console
        DisplayClient(client);

        //------------ Task 2 ------------
        //Asking user want to invest
        do {
            System.out.print("Would you like to invest (Y/N)? ");
            response = scanner.nextLine().trim().toLowerCase();


            if (response.equals("y") || response.equals("yes")) {
                invest = true;
            } else if (response.equals("n") || response.equals("no")) {
                invest = false;
            } else {
                System.out.println("Error: Invalid input. Please enter Yes/No or Y/N.");
                invest = false; // reset resident too false to repeat loop
            }

        } while (!response.equals("y") && !response.equals("yes") && !response.equals("n") && !response.equals("no"));

        // If user do not want program end
        if (!invest) return;

        // Asking user weekly expenses, set amount
        double weeklyExpenses;
        do {
            System.out.println("Enter your weekly expenses: ");
            weeklyExpenses = scanner.nextDouble();

            if (weeklyExpenses <= 0) {
                System.out.println("Weekly expenses must be a positive number and different from zero.");
            }
        } while (weeklyExpenses <= 0);


        // Asking if user income is sufficient to cover his expenses
        boolean isSufficient = false;
        do {
            if (client.getNetSalaryPerWeek() >= weeklyExpenses) {
                System.out.println("Your income is sufficient to cover your expenses.");
                isSufficient = true;
            } else {
                System.out.println("Warning: Your income is not sufficient to cover your expenses.");

                System.out.print("Would you like to enter a new expenditure? (y/n) ");
                String answer = scanner.next();

                if (answer.equalsIgnoreCase("y")) {
                    System.out.print("Please enter your new weekly living expenses: ");
                    double newWeeklyExpenses = scanner.nextDouble();

                    if (newWeeklyExpenses <= 0) {
                        System.out.println("Error: Weekly expenses must be a positive number.");
                        continue;
                    }

                    if (client.getNetSalaryPerWeek() >= newWeeklyExpenses) {
                        System.out.println("Your income is now sufficient to cover your expenses.");
                        isSufficient = true;
                    } else {
                        System.out.println("Your income is still not sufficient to cover your expenses. Goodbye!");
                    }
                } else {
                    System.out.println("Goodbye!");
                    System.exit(0);
                }
            }

        } while (!isSufficient);



        //Enter the interest rate of the investment account (between 1% and 20%)
        double interestRate = 0;
        while (true) {
            System.out.print("Enter the interest rate of the investment account (between 1% and 20%): ");
            if (scanner.hasNextDouble()) {
                interestRate = scanner.nextDouble();
                if (interestRate >= 1 && interestRate <= 20) {
                    interestRate /= 100; // convert from percentage to decimal
                    break;
                } else {
                    System.out.println("Error: Interest rate must be between 1% and 20%.");
                }
            } else {
                System.out.println("Error: Invalid input. Please enter a number.");
                scanner.next(); // consume the invalid input
            }
        }


        //investment length (in weeks)
        int investmentLength = 0;
        boolean isValid = false;
        while (!isValid) {
            System.out.print("Enter the investment length (in weeks): ");
            if (scanner.hasNextInt()) {
                investmentLength = scanner.nextInt();
                if (investmentLength > 0) {
                    isValid = true;
                } else {
                    System.out.println("Investment length must be a positive number!");
                }
            } else {
                System.out.println("Invalid input! Please enter a positive integer.");
            }
        }

        client.getSavingAccount().setAmount(weeklyExpenses);
        client.getSavingAccount().setRate(interestRate);
        client.getSavingAccount().setNumberOfWeeks(investmentLength);

        System.out.println(client.getSavingAccount().calcInvestment());

    }

    private static void DisplayClient(Client client) {
        System.out.printf("Name: %s %s%n%n", client.getName(), client.getSurname());
        System.out.println("Net Salary");
        System.out.printf("Per week: $%.2f%n", client.getNetSalaryPerWeek());
        System.out.printf("Per year: $%.2f%n%n", client.getNetSalary());
        System.out.println("Tax Paid");
        System.out.printf("Tax amount per week: $%.2f%n", client.getTax() / WEEKS_IN_YEAR);
        System.out.printf("Tax amount per year: $%.2f%n%n", client.getTax());
        System.out.printf("Medicare levy per week: $%.2f%n", client.getMedicare() / WEEKS_IN_YEAR);
        System.out.printf("Medicare levy per year: $%.2f%n%n", client.getMedicare());
    }


}
